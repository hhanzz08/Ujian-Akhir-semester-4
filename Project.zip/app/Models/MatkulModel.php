<?php

namespace App\Models;

use CodeIgniter\Model;

class MatkulModel extends Model
{
    protected $table = 'matakuliah';
    protected $primaryKey = 'id_matakuliah';
    protected $allowedFields = ['mata_kuliah'];

    public function getMatkul($id = null)
    {
        if ($id === null) {
            return $this->findAll();
        }

        return $this->find($id);
    }
}